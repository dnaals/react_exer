import React from 'react'

function Props() {
  return (
    <div>Props</div>
  )
}

export default Props