import React from 'react'

function 페이지없음() {
  return (
    <div>페이지없음</div>
  )
}

export default 페이지없음