import React from 'react'

function Deploy() {
  return (
    <div>
      Deploy
    </div>
  )
}

export default Deploy